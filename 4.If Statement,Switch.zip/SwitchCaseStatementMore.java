package basic;

import java.util.Scanner;

public class SwitchCaseStatementMore {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//switch..case with String
		
		System.out.print("Enter your favourite character: ");
		String name = sc.next().toLowerCase();
		
		switch(name) {
		case "harry": System.out.println("Harry Potter");
						break;
		case "frodo": System.out.println("Frodo Baggins");
						break;
		default: System.out.println("Don't know this character");
		}
		
		//switch..case with character
		System.out.println("Enter any single character ");
		char c = sc.next().toLowerCase().charAt(0);
		
		switch(c) {
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':System.out.println("Vowel");
				break;
		default: System.out.println("Consonent");
		
		}
		
		float f = 89.45f;
		//switch(f) {}

	}
}
