package basic;

import java.util.Scanner;

/*Write a program to take the marks of the student 
 *and find the grade based on the following chart:
 *
 *range			grade
 *100-75		A
 *75-60			B
 *60-35			C
 *35-0			D
 */

public class LogicalAndOperator {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the marks: ");
		int marks = s.nextInt();
		
		//if else ladder
		if(marks<=100 && marks>=75)
			System.out.println("A");
		else if(marks<75 && marks>=60)
			System.out.println("B");
		else if(marks<60 && marks>=35)
			System.out.println("C");
		else if(marks<35 && marks>=0)
			System.out.println("D");
		else
			System.out.println("Invalid Marks");
	}
}
