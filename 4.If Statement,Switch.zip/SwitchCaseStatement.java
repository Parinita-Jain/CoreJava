package basic;

import java.util.Scanner;

/*Write a program to take a number between 1 and 7
 * from the user and based on the number, 
 * specify the day of the week.
 * 1 ===> Sunday
 * 2 ===> Monday
 * .....
 */

public class SwitchCaseStatement {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any number between 1 and 7: ");
		int num = s.nextInt();
		
		switch(num) {
		case 5:System.out.println("Thursday");
				break;
		case 1:System.out.println("Sunday");
				break;
		case 2:System.out.println("Monday");
				break;
		case 6:System.out.println("Friday");
				break;
		case 3:System.out.println("Tuesday");
				break;
		default: System.out.println("Invalid Number");
				break;
		case 4:System.out.println("Wednesday");
				break;		
		case 7:System.out.println("Saturday");		
		}
	}

}
