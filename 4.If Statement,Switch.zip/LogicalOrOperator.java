package basic;

import java.util.Scanner;

/*Write a program to check if the character entered by user
 * is a vowel or consonent
 */

public class LogicalOrOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter any single character: ");
		char c = scan.next().toLowerCase().charAt(0);
		
		if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u')
			System.out.println("Vowel");
		else
			System.out.println("Consonent");
	}
}
