package basic;

import java.util.Scanner;

/*Write a program to take the marks of the student
 * and specify if the student has passed(marks>35)
 *  or failed 
 * 
 */

public class TernaryOperation {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the marks ");
		float marks = s.nextFloat();
		
		/*if(marks>35)
			System.out.println("Passed");
		else
			System.out.println("Failed");
		*/
		
		String result = (marks>35) ? "Passed" : "Failed";
		System.out.println(result);
		
		System.out.println("Enter any number");
		int num = s.nextInt();
		
		result = (num%2==0) ? "even" : "odd";
		System.out.println(result);
	}
}
