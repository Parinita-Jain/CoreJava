package basic;

import java.util.Scanner;

/*
 * Write a program to find if the number entered by the user
 * is divisible by 5, 7 or both
 */
public class NestedIfStatement {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter any number ");
		int num = s.nextInt();
		
		if(num%5==0) {
			if(num%7==0) 
				System.out.println("Number is divisible by 5 and 7");
			else 
				System.out.println("Number is divisible by 5 but not by 7");
		}
		else {
			if(num%7==0) 
				System.out.println("Number is divisible by 7 but not by 5");
			else
				System.out.println("Number is not divisible by 5 and 7");
		}
			
	}
}
