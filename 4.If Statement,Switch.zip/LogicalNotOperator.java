package basic;

import java.util.Scanner;

/*Write a program to check if the number entered is even or odd
 * using Not operator
 */

public class LogicalNotOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter any number ");
		int num = scan.nextInt();
		
		if(!(num%2==0))
			System.out.println("Odd Number");
		else
			System.out.println("Even Number");
	}

}
