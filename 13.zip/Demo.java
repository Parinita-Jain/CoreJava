package inheritance;

public class Demo {
	protected void displayMessage() {
		System.out.println("Default method of Demo class");
	}
}
