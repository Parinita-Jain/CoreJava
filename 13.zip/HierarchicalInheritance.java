package inheritance;

class Shape{
	void display() {
		System.out.println("Class Shape");
	}
}

class Rectangle extends Shape{
	
}

class Square extends Shape{
	
}

class Triangle extends Shape{
	
}

public class HierarchicalInheritance {

	public static void main(String[] args) {
	}

}
