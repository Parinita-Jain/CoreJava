package com.itvedant.faculty;

//import com.itvedant.student.Student;
//import com.itvedant.student.Exam;

import com.itvedant.student.*;

public class Faculty {

	public static void main(String[] args) {
		Student s = new Student();
		Exam e;
	}

}
