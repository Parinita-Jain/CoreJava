package basic;

import oopsbasic.B;

public class AccessModifiersImplementationDifferentPackage {

	public static void main(String[] args) {
		B b = new B();
		b.a = 10;
		//b.abc;
		
		//b.method1();
	}

}
