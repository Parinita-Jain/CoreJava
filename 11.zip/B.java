package oopsbasic;

public class B {
	public int a;
	
	private int abc;
	
	void display() {}
	
	protected void method1() {}
}
