package com.itvedant.student;

public class Exam {

}
