package com.itvedant.student;

public class Student {
	public void msg() {
		System.out.println("Hello from student");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
