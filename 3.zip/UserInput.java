package basic;

import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter any integer number");
		int i = s.nextInt();
		System.out.println("Value Entered = " + i);
		
		System.out.println("Enter any decimal number");
		float f = s.nextFloat();
		System.out.println("Value Entered = " + f);
		
		System.out.print("Enter Your Name: ");
		String name = s.next();
		System.out.println("Name = " + name);
	}

}
