package basic;

public class Typecasting {
	public static void main(String[] args) {
		//Implicit Typecasting, done by compiler
		short s = 90;
		int i = s; //short -> int
		
		float f = s; //short -> float
		
		int a = 68253;
		float f1 = a; //int -> float
		
		char c = 'o';
		int val = c; //char -> int		
		
		//Explicit Typecasting, done by programmer
		float ff = 78.34f;
		int ii = (int)ff;  //float -> int
		System.out.println(ii);
		
		int val1 = 190;
		byte b = (byte)val1;
		System.out.println(b);
		
		int val2 = 68;
		char c1 = (char)val2;
		System.out.println(c1);
	}

}
