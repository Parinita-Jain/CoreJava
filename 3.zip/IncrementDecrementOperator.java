package basic;

public class IncrementDecrementOperator {
	public static void main(String[] args) {
		int a = 10;
		
		System.out.println("Pre Increment");
		System.out.println("a = " + a);
		//Pre-increment
		//1. increment the value of variable a by 1
		//2. assign the value of a to variable b
		int b = ++a;
		System.out.println("b = " + b);
		System.out.println("a = " + a);
		
		//Post-increment
		a = 10;		
		System.out.println("Post Increment");
		System.out.println("a = " + a);
		//Post-increment
		//1. assign the value of a to variable b
		//2. increment the value of variable a by 1
		b = a++;
		System.out.println("b = " + b);
		System.out.println("a = " + a);
		
		//Pre-decrement
		a = 10;		
		System.out.println("Pre Decrement");
		System.out.println("a = " + a);
		//Post-increment
		//1. decrement the value of variable a by 1
		//2. assign the value of a to variable b
		b = --a;
		System.out.println("b = " + b);
		System.out.println("a = " + a);
		
		//Post-decrement
		a = 10;		
		System.out.println("Post Decrement");
		System.out.println("a = " + a);
		//Post-increment
		//1. assign the value of a to variable b
		//2. decrement the value of variable a by 1
		b = a--;
		System.out.println("b = " + b);
		System.out.println("a = " + a);
	}
}
