package basic;

import java.util.Scanner;

/*Write a program to take the input from the user
and check if the value entered is positive*/
public class SimpleIfStatement {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any number ");
		int num = s.nextInt();
		
		if(num>0) 
			System.out.println("Number entered is positive");
	}
}
