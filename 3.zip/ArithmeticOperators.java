package basic;

public class ArithmeticOperators {
	public static void main(String[] args) {
		//assignment operator, assigning the literal value to the variable
		int m = 10;
		
		//assignment operator, assigning the result of the operation to the variable
		int sum = 10 + 12;
		System.out.println(sum);
		
		//If both operands are int
		int a = 10;
		int b = 4;
		
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		
		//If both operands are float
		float x = 7.5f;
		float y = 6.3f;
		
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);
		System.out.println(x%y);
		
		//If one operand is float and another is int
		//Compiler is converting int value into float implicitly
		//After this arithmetic operation is performed
		System.out.println(a+x);
		System.out.println(a-x);
		System.out.println(a*x);
		System.out.println(a/x);
		System.out.println(a%x);
		
		//If both operands are char
		//first, compiler will convert int char value in int
		//this int value is the ASCII value of the char
		//so the arithmetic operation is performed on this int value 
		char c1 = 'a';
		char c2 = 'b';
		System.out.println(c1+c2);
		System.out.println(c1-c2);
		System.out.println(c1*c2);
		System.out.println(c1/c2);
		System.out.println(c1%c2);
		
		//If both operands are boolean or any one is boolean
		//we cannot perform any arithmetic operation on boolean
		boolean val = true;
		//System.out.println(val + 1);
		
		//If both operands are String, we can perform
		//only addition operation and this is also 
		//known as concatenation
		String s1 = "hello";
		String s2 = "world";
		System.out.println(s1 + s2);
		
		//If one operand is String and another 
		//is of any other primitive datatype
		//This primitive value will be implicitly converted
		//into String and then addition operation is performed
		System.out.println("hello" + 1);
		System.out.println("Float" + 78.345f);
		System.out.println("Boolean" + true);
	}

}
