package basic;

public class Variables {
	public static void main(String[] args) {
		//System.out.println("Welcome to Java Eclipse IDE");
		
		//Number (whole number)
		byte b = 127;
		short s = 8745;
		int i = 48495933;
		
		/*Normal whole number literal is considered as int,
		 If that literal has to be considered as long, we need
		 suffix the literal with l or L*/
		long l = 496849568456969L;
		
		//Number (decimal number)
		/*Normal decimal number literal is considered as double,
		 * If that literal has to be considered as float, we need
		 * to suffix the literal with f or F*/
		float f = 784.45f;
		
		/*If we want to specify the literal as double 
		 * we can suffix the literal with d or D*/
		double d = 78345.4758d;
		
		//Character
		char c1 = 'a';
		char c2 = '%';
		
		//Boolean
		boolean b1 = true;
		boolean b2 = false;
		
		int ab;
		int m,n,o;
		
		//String
		String str = "string literal";
		
		System.out.println(b);
	}
}
