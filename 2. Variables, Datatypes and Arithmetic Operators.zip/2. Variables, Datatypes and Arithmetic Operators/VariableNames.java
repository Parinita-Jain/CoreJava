package basic;

public class VariableNames {
	public static void main(String[] args) {
		//should contain letters, digits, underscore or dollar only
		int a = 10; //valid
		int abc1 = 69; //valid
		int eng_marks = 89; //valid
		float sci$marks = 78.45f; //valid
		
		//float d)m, a n;   //invalid
		
		//should not start with digit, 
		//but can start with letter, underscore or dollar
		//int 8fd; //invalid
		int ab56, _1, __, $, $df, $3, $_, _$ ;  //valid
		
		//case-sensitive
		int ab,aB,Ab,AB;  //all four are different
		
		//reserved keywords
		//int try;  //invalid
	}

}
