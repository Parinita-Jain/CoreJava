package basic;

public class ArithmeticOperators {

	public static void main(String[] args) {
		//assignment operator, assigning the literal value to the variable
		int m = 10;
		
		//assignment operator, assigning the result of the operation to the variable
		int sum = 10 + 12;
		System.out.println(sum);
		
		//If both operands are int
		int a = 10;
		int b = 4;
		
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
	}

}
